D.A Plugins / Manual revision 1.1 / Rack Collection 02
English: 51 pages. Persian: 51 pages. Combined: 102 pages.
Documentation only, not a commercial plugin installer.
Source: 625ea12. Date: 2026-10-23.

راهنماهای فارسی، انگلیسی و ترکیبی؛ هر سه PDF داخل این بسته هستند.
این فایل فقط مستندات است، نه نصب‌کنندهٔ پلاگین.
