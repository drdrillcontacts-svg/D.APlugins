D.A Plugins 0.4 / DEVELOPMENT SOURCE + DVERB LISTENING AID
Audio implementation source checkpoint: 74d1809be96f

This is NOT a plugin installer or a signed/certified commercial release.
All ten products, 50 factory programs each, DDelay sync and revised DVerb/DFX
are included as buildable source. Compiled binaries depend on platform CI;
see https://github.com/drdrillcontacts-svg/D.APlugins/actions

Build the ten VST3/Standalone targets (macOS also AU):
 cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
 cmake --build build --config Release --parallel 2
Requires CMake 3.22+, C++17 compiler, network for pinned JUCE 8.0.6,
platform JUCE development dependencies and applicable JUCE licensing.
Linux needs pkg-config, ALSA/JACK, freetype/fontconfig and X11/GL dev packages.
Portable tests without JUCE:
 cmake -S . -B build-core -DDA_BUILD_PLUGINS=OFF -DCMAKE_BUILD_TYPE=Release
 cmake --build build-core --config Release --parallel 2
 ctest --test-dir build-core -C Release --output-on-failure
The full repository includes the CI dependency list and additional documentation.

Preset catalogs: Design/Presets/FactoryPresets.json (500 complete snapshots).
Manuals are a SEPARATE ZIP:
 https://github.com/drdrillcontacts-svg/D.APlugins/blob/arena/0bdc5081-d-aplugins/docs/manual/pdf/DA_Plugins_Manuals_EN_FA.zip?raw=true

Audio: original synthetic plucked tones/noise percussion, 8 s, 48 kHz stereo,
24-bit PCM. No third-party recording. 01 and 02 are WET ONLY, identical input
and explicitly identical parameters, before=63e91b9, after=current implementation.
Both are independently RMS-matched over the full eight seconds to -27 dBFS,
with a -0.54 dBFS peak ceiling; Level_matching.json reports any ceiling limitation.
Listen on modest monitoring, then audition real sources in a host. The example
is not a subjective sound-quality approval or measurement of calibrated RT60.
Reproduce the raw data with tools/render_reverb_demo.cpp against each Suite.cpp.
The reverb algorithm changes old-session sound; keep your previous binary.
No trained neural model, activation, signed installer or commercial clearance
is included. LICENSE-NOTICE.txt and font/JUCE obligations apply.
